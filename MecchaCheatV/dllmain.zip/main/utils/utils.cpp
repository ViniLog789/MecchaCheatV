#include "utils.h"

namespace fs = std::filesystem;

std::string Utils::GetCheatDirectory()
{
    return "C:\\VComDev\\MecchaCheatV";
}

void Utils::CreateCheatDirectory()
{
    try
    {
        const std::string baseDir = "C:\\VComDev";
        const std::string cheatDir = baseDir + "\\MecchaCheatV";
        const std::string configDir = cheatDir + "\\configs";

        if (!fs::exists(baseDir))
        {
            LOG_INFO("Creating base directory");
            fs::create_directory(baseDir);
        }

        if (!fs::exists(cheatDir))
        {
            LOG_INFO("Creating cheat directory");
            fs::create_directory(cheatDir);
        }

        if (!fs::exists(configDir))
        {
            LOG_INFO("Creating config directory");
            fs::create_directory(configDir);
        }
    }
    catch (const std::filesystem::filesystem_error& e)
    {
        LOG_ERROR("Filesystem error: %s", e.what());
    }
}

// Taken from OmegaWare-Framework.
SDK::AGameStateBase* Utils::GetGameStateBase()
{
    SDK::UWorld* pGWorld = SDK::UWorld::GetWorld();
    if (!pGWorld)
        return nullptr;

    SDK::AGameStateBase* pGameState = pGWorld->GameState;
    if (!pGameState)
        return nullptr;

    return pGameState;
}

// Taken from OmegaWare-Framework.
SDK::UGameInstance* Utils::GetGameInstance()
{
    SDK::UWorld* pGWorld = SDK::UWorld::GetWorld();
    if (!pGWorld)
        return nullptr;

    SDK::UGameInstance* pGameInstance = pGWorld->OwningGameInstance;
    if (!pGameInstance)
        return nullptr;

    return pGameInstance;
}

// Taken from OmegaWare-Framework.
SDK::ULocalPlayer* Utils::GetLocalPlayer(int index)
{
    SDK::UGameInstance* pGameInstance = GetGameInstance();
    if (!pGameInstance)
        return nullptr;

    SDK::ULocalPlayer* pLocalPlayer = pGameInstance->LocalPlayers[index];
    if (!pLocalPlayer)
        return nullptr;

    return pLocalPlayer;
}

// Taken from OmegaWare-Framework.
SDK::UGameViewportClient* Utils::GetViewportClient()
{
    SDK::ULocalPlayer* pLocalPlayer = GetLocalPlayer();
    if (!pLocalPlayer)
        return nullptr;

    SDK::UGameViewportClient* pViewportClient = pLocalPlayer->ViewportClient;
    if (!pViewportClient)
        return nullptr;

    return pViewportClient;
}

// Taken from OmegaWare-Framework.
SDK::APlayerController* Utils::GetPlayerController()
{
    SDK::ULocalPlayer* pLocalPlayer = GetLocalPlayer();
    if (!pLocalPlayer)
        return nullptr;

    SDK::APlayerController* pPlayerController = pLocalPlayer->PlayerController;
    if (!pPlayerController)
        return nullptr;

    return pPlayerController;
}

// Taken from OmegaWare-Framework.
SDK::APawn* Utils::GetAcknowledgedPawn()
{
    SDK::APlayerController* pPlayerController = GetPlayerController();
    if (!pPlayerController)
        return nullptr;

    SDK::APawn* pAcknowledgedPawn = pPlayerController->AcknowledgedPawn;
    if (!pAcknowledgedPawn)
        return nullptr;

    return pAcknowledgedPawn;
}

// Taken from OmegaWare-Framework.
SDK::APlayerCameraManager* Utils::GetPlayerCameraManager()
{
    SDK::APlayerController* pPlayerController = GetPlayerController();
    if (!pPlayerController)
        return nullptr;

    SDK::APlayerCameraManager* pPlayerCameraManager = pPlayerController->PlayerCameraManager;
    if (!pPlayerCameraManager)
        return nullptr;

    return pPlayerCameraManager;
}

// Taken from OmegaWare-Framework.
bool Utils::WorldToScreen(SDK::FVector in, SDK::FVector2D& out, bool relative)
{
    SDK::APlayerController* pPlayerController = GetPlayerController();
    if (!pPlayerController)
        return false;

    return pPlayerController->ProjectWorldLocationToScreen(in, &out, relative);
}

// Taken from OmegaWare-Framework.
SDK::FVector2D Utils::W2S(SDK::FVector in, bool relative)
{
    SDK::FVector2D out{ 0.f, 0.f };

    SDK::APlayerController* pPlayerController = GetPlayerController();
    if (!pPlayerController)
        return out;

    pPlayerController->ProjectWorldLocationToScreen(in, &out, relative);

    return out;
}

bool Utils::IsInMatch(SDK::UWorld* World)
{
    auto PC = SDK::UGameplayStatics::GetPlayerController(World, 0);

    return PC
        && PC->K2_GetPawn()
        && World
        && World->GameState;
}

std::string Utils::getKeyName(int keyCode)
{
    switch (keyCode)
    {
    case VK_INSERT: return "INSERT";
    case VK_DELETE: return "DELETE";
    case VK_HOME: return "HOME";
    case VK_END: return "END";
    case VK_PRIOR: return "PAGE UP";
    case VK_NEXT: return "PAGE DOWN";
    case VK_F1: return "F1";
    case VK_F2: return "F2";
    case VK_F3: return "F3";
    case VK_F4: return "F4";
    case VK_F5: return "F5";
    case VK_F6: return "F6";
    case VK_F7: return "F7";
    case VK_F8: return "F8";
    case VK_F9: return "F9";
    case VK_F10: return "F10";
    case VK_F11: return "F11";
    case VK_F12: return "F12";
    case VK_RETURN: return "Enter";
    default:
        if (keyCode >= 'A' && keyCode <= 'Z')
            return std::string(1, (char)keyCode);
        else if (keyCode >= '0' && keyCode <= '9')
            return std::string(1, (char)keyCode);
        else
            return "Key " + std::to_string(keyCode);
    }
}