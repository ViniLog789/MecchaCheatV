#include "Includes.h"

using namespace MecchaCheatV;

HRESULT __stdcall Hooks::HkPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags)
{
    if (!menu.Initialized)
    {
        if (SUCCEEDED(pSwapChain->GetDevice(__uuidof(ID3D12Device), reinterpret_cast<void**>(&Renderer::Device))))
        {
            Renderer::Swapchain = static_cast<IDXGISwapChain3*>(pSwapChain);

            DXGI_SWAP_CHAIN_DESC desc;
            pSwapChain->GetDesc(&desc);
            Renderer::Window = desc.OutputWindow;
            Renderer::BuffersCount = desc.BufferCount;

            Renderer::FrameContexts = new FrameContext[Renderer::BuffersCount];

            D3D12_COMMAND_QUEUE_DESC queueDesc{};
            queueDesc.Type = D3D12_COMMAND_LIST_TYPE_DIRECT;
            queueDesc.Priority = 0;
            queueDesc.Flags = D3D12_COMMAND_QUEUE_FLAG_NONE;
            queueDesc.NodeMask = 0;
            Renderer::Device->CreateCommandQueue(&queueDesc, __uuidof(ID3D12CommandQueue), reinterpret_cast<void**>(&Renderer::CommandQueue));

            D3D12_DESCRIPTOR_HEAP_DESC rtvHeapDesc{};
            rtvHeapDesc.NumDescriptors = Renderer::BuffersCount;
            rtvHeapDesc.Type = D3D12_DESCRIPTOR_HEAP_TYPE_RTV;
            rtvHeapDesc.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_NONE;
            Renderer::Device->CreateDescriptorHeap(&rtvHeapDesc, __uuidof(ID3D12DescriptorHeap), reinterpret_cast<void**>(&Renderer::RtvDescHeap));

            D3D12_DESCRIPTOR_HEAP_DESC srvHeapDesc{};
            srvHeapDesc.NumDescriptors = 1;
            srvHeapDesc.Type = D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV;
            srvHeapDesc.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
            Renderer::Device->CreateDescriptorHeap(&srvHeapDesc, __uuidof(ID3D12DescriptorHeap), reinterpret_cast<void**>(&Renderer::SrvDescHeap));

            SIZE_T rtvDescriptorSize = Renderer::Device->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV);
            D3D12_CPU_DESCRIPTOR_HANDLE rtvHandle = Renderer::RtvDescHeap->GetCPUDescriptorHandleForHeapStart();

            for (UINT i = 0; i < Renderer::BuffersCount; i++)
            {
                Renderer::FrameContexts[i].MainRenderTargetDescriptor = rtvHandle;
                pSwapChain->GetBuffer(i, __uuidof(ID3D12Resource), reinterpret_cast<void**>(&Renderer::FrameContexts[i].MainRenderTargetResource));
                Renderer::Device->CreateRenderTargetView(Renderer::FrameContexts[i].MainRenderTargetResource, nullptr, rtvHandle);
                rtvHandle.ptr += rtvDescriptorSize;

                Renderer::Device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, __uuidof(ID3D12CommandAllocator), reinterpret_cast<void**>(&Renderer::FrameContexts[i].CommandAllocator));
            }

            Renderer::Device->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, Renderer::FrameContexts[0].CommandAllocator, nullptr, __uuidof(ID3D12GraphicsCommandList), reinterpret_cast<void**>(&Renderer::CommandList));
            Renderer::CommandList->Close();

            ImGui::CreateContext();
            ImGui_ImplWin32_Init(Renderer::Window);
            ImGui_ImplDX12_Init(Renderer::Device, Renderer::BuffersCount,
                DXGI_FORMAT_R8G8B8A8_UNORM, Renderer::SrvDescHeap,
                Renderer::SrvDescHeap->GetCPUDescriptorHandleForHeapStart(),
                Renderer::SrvDescHeap->GetGPUDescriptorHandleForHeapStart());

            ImGui::GetIO().ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
            ImGui::LoadIniSettingsFromDisk((Utils::GetCheatDirectory() + "\\menu.ini").c_str());
            ImGui::GetIO().FontGlobalScale = dpiScale;

            hooking->OriginalWndproc = reinterpret_cast<WNDPROC>(SetWindowLongPtr(Renderer::Window, GWLP_WNDPROC,
                reinterpret_cast<LONG_PTR>(HkWndProc)));

            Menu::Initialize();
        }
        else
        {
            return hooking->OriginalPresent(pSwapChain, SyncInterval, Flags);
        }
    }

    if (!Renderer::CommandQueue)
    {
        return hooking->OriginalPresent(pSwapChain, SyncInterval, Flags);
    }

    UINT currBackBufferIndex = Renderer::Swapchain->GetCurrentBackBufferIndex();
    FrameContext& currentFrameContext = Renderer::FrameContexts[currBackBufferIndex];

    currentFrameContext.CommandAllocator->Reset();
    Renderer::CommandList->Reset(currentFrameContext.CommandAllocator, nullptr);

    D3D12_RESOURCE_BARRIER barrier{};
    barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    barrier.Flags = D3D12_RESOURCE_BARRIER_FLAG_NONE;
    barrier.Transition.pResource = currentFrameContext.MainRenderTargetResource;
    barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_PRESENT;
    barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_RENDER_TARGET;
    Renderer::CommandList->ResourceBarrier(1, &barrier);

    Renderer::CommandList->OMSetRenderTargets(1, &currentFrameContext.MainRenderTargetDescriptor, FALSE, nullptr);
    Renderer::CommandList->SetDescriptorHeaps(1, &Renderer::SrvDescHeap);

    ImGui_ImplDX12_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    if (menu.Open)
    {
        GET_FEATURE_HANDLER()->ApplyConfigStates();
        Menu::Render();
    }

    if (GET_FEATURE_HANDLER())
    {
        GET_FEATURE_HANDLER()->RenderAll();
    }

    Notifications::RenderNotifications();

    ImGui::EndFrame();
    ImGui::Render();

    ImGui_ImplDX12_RenderDrawData(ImGui::GetDrawData(), Renderer::CommandList);

    barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_RENDER_TARGET;
    barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_PRESENT;
    Renderer::CommandList->ResourceBarrier(1, &barrier);

    Renderer::CommandList->Close();

    ID3D12CommandList* ppCommandLists[] = { Renderer::CommandList };
    Renderer::CommandQueue->ExecuteCommandLists(1, ppCommandLists);

    return hooking->OriginalPresent(pSwapChain, SyncInterval, Flags);
}