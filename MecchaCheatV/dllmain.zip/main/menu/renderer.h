#pragma once
#include "Includes.h"
#include <d3d12.h>
#include <dxgi1_4.h>
#pragma comment(lib, "d3d12.lib")
#pragma comment(lib, "dxgi.lib")

namespace MecchaCheatV
{
	using Id3DPresent = HRESULT(__stdcall*)(IDXGISwapChain* this_, UINT sync_, UINT flags_);

	struct FrameContext
	{
		ID3D12CommandAllocator* CommandAllocator;
		ID3D12Resource* MainRenderTargetResource;
		D3D12_CPU_DESCRIPTOR_HANDLE MainRenderTargetDescriptor;
	};

	class Renderer
	{
	public:
		explicit Renderer();
		~Renderer();
		bool GetSwapChain(IDXGISwapChain** swapChain, ID3D12Device** device, ID3D12CommandQueue** queue) const;
		Id3DPresent GetPresent() const;

		static inline IDXGISwapChain3* Swapchain = nullptr;
		static inline HWND Window = nullptr;
		static inline ID3D12Device* Device = nullptr;
		static inline ID3D12CommandQueue* CommandQueue = nullptr;
		static inline ID3D12DescriptorHeap* RtvDescHeap = nullptr;
		static inline ID3D12DescriptorHeap* SrvDescHeap = nullptr;
		static inline ID3D12GraphicsCommandList* CommandList = nullptr;
		static inline FrameContext* FrameContexts = nullptr;
		static inline UINT BuffersCount = 0;
	};

	inline Renderer* renderer{};
}