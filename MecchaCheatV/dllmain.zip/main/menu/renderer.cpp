#include "renderer.h"

using namespace MecchaCheatV;

Renderer::Renderer()
{
	renderer = this;
}

Renderer::~Renderer()
{
	if (FrameContexts)
	{
		delete[] FrameContexts;
		FrameContexts = nullptr;
	}
	renderer = nullptr;
}

bool Renderer::GetSwapChain(IDXGISwapChain** swapChain, ID3D12Device** device, ID3D12CommandQueue** queue) const
{
	WNDCLASSEX wc{ 0 };
	wc.cbSize = sizeof(wc);
	wc.lpfnWndProc = DefWindowProc;
	wc.lpszClassName = TEXT("MecchaCheatV");
	wc.hInstance = GetModuleHandle(nullptr);

	if (!RegisterClassEx(&wc))
	{
		return false;
	}

	HWND hwnd = CreateWindowEx(
		0,
		wc.lpszClassName,
		TEXT(""),
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		100,
		100,
		nullptr,
		nullptr,
		wc.hInstance,
		nullptr);

	if (!hwnd)
	{
		UnregisterClass(wc.lpszClassName, wc.hInstance);
		return false;
	}

	if (FAILED(D3D12CreateDevice(nullptr, D3D_FEATURE_LEVEL_11_0, __uuidof(ID3D12Device), reinterpret_cast<void**>(device))))
	{
		DestroyWindow(hwnd);
		UnregisterClass(wc.lpszClassName, wc.hInstance);
		return false;
	}

	D3D12_COMMAND_QUEUE_DESC queueDesc{};
	queueDesc.Type = D3D12_COMMAND_LIST_TYPE_DIRECT;
	queueDesc.Priority = 0;
	queueDesc.Flags = D3D12_COMMAND_QUEUE_FLAG_NONE;
	queueDesc.NodeMask = 0;

	if (FAILED((*device)->CreateCommandQueue(&queueDesc, __uuidof(ID3D12CommandQueue), reinterpret_cast<void**>(queue))))
	{
		(*device)->Release();
		DestroyWindow(hwnd);
		UnregisterClass(wc.lpszClassName, wc.hInstance);
		return false;
	}

	IDXGIFactory4* factory = nullptr;
	if (FAILED(CreateDXGIFactory1(__uuidof(IDXGIFactory4), reinterpret_cast<void**>(&factory))))
	{
		(*queue)->Release();
		(*device)->Release();
		DestroyWindow(hwnd);
		UnregisterClass(wc.lpszClassName, wc.hInstance);
		return false;
	}

	DXGI_SWAP_CHAIN_DESC1 swapChainDesc{};
	swapChainDesc.BufferCount = 2;
	swapChainDesc.Width = 100;
	swapChainDesc.Height = 100;
	swapChainDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	swapChainDesc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	swapChainDesc.SwapEffect = DXGI_SWAP_EFFECT_FLIP_DISCARD;
	swapChainDesc.SampleDesc.Count = 1;

	IDXGISwapChain1* tempSwapChain = nullptr;
	HRESULT hr = factory->CreateSwapChainForHwnd(*queue, hwnd, &swapChainDesc, nullptr, nullptr, &tempSwapChain);

	factory->Release();
	DestroyWindow(hwnd);
	UnregisterClass(wc.lpszClassName, wc.hInstance);

	if (FAILED(hr))
	{
		(*queue)->Release();
		(*device)->Release();
		return false;
	}

	*swapChain = tempSwapChain;
	return true;
}

Id3DPresent Renderer::GetPresent() const
{
	IDXGISwapChain* swapChain = nullptr;
	ID3D12Device* device = nullptr;
	ID3D12CommandQueue* queue = nullptr;

	if (GetSwapChain(&swapChain, &device, &queue))
	{
		void** vmt = *reinterpret_cast<void***>(swapChain);

		if (swapChain)
		{
			swapChain->Release();
			swapChain = nullptr;
		}
		if (queue)
		{
			queue->Release();
			queue = nullptr;
		}
		if (device)
		{
			device->Release();
			device = nullptr;
		}

		return static_cast<Id3DPresent>(vmt[8]);
	}

	return nullptr;
}